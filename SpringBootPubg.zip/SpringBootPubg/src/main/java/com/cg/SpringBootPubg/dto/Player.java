package com.cg.SpringBootPubg.dto;



import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.stereotype.Component;



@Entity
@Table(name="player_pubg")

public class Player {

	@Id
	@Column(name="player_id")
	private int pid;
	@Column(name="player_name")
	private String name;
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="player_id")
	private List<Tournament>tournament;
	public Player() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Player(int pid, String name, List<Tournament> tournament) {
		super();
		this.pid = pid;
		this.name = name;
		this.tournament = tournament;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Tournament> getTournament() {
		return tournament;
	}
	public void setTournament(List<Tournament> tournament) {
		this.tournament = tournament;
	}
	@Override
	public String toString() {
		return "Player [pid=" + pid + ", name=" + name + ", tournament=" + tournament + "]";
	}
	
	
}
