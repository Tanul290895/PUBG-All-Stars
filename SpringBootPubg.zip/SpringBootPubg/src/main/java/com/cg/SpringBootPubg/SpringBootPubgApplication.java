package com.cg.SpringBootPubg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg")
public class SpringBootPubgApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootPubgApplication.class, args);
		System.out.println("Welcome to Pubg All Stars");
	}

}
