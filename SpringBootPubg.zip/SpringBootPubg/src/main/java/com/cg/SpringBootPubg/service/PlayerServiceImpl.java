package com.cg.SpringBootPubg.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.SpringBootPubg.dao.PlayerDao;
import com.cg.SpringBootPubg.dto.Player;
import com.cg.SpringBootPubg.dto.Tournament;



@Service
@Transactional
public class PlayerServiceImpl implements PlayerService{
	
	@Autowired
	PlayerDao playerDao;

	



	@Override
	public List<Tournament> serachByMode(String mode) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Tournament> searchByMap(String map)  {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Player addPlayer(Player player) {
		// TODO Auto-generated method stub
		List<Tournament> trnmntlist=new ArrayList<>();
		
//		int playerId=player.getPid();
//		Player ply=playerDao.findBypid(playerId);
//		 trnmntlist=ply.getTournament();
//		 player.setTournament(trnmntlist);
		
		

		
		return  playerDao.save(player);
		
		
	

		
	
	    
		
	
	}

	@Override
	public List<Tournament> showAll() {
		return null;
		// TODO Auto-generated method stub
		//return playerDao.findAll();
				
	}

	

	
}
