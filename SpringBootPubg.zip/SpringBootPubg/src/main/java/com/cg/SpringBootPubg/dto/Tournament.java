package com.cg.SpringBootPubg.dto;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;

@Entity
@Table(name="tournament_pubg")
public class Tournament {

	@Id
	@Column(name="tournamentid")
	private int tourid;
	@Column(name="map")
	private String map;
	@Column(name="mode")
	private String modeType;
	@Column(name="type")
	private String gameType;
	@Column(name="gameid")
	private int game_id;
	@Column(name="gamekey")
	private String gameKey;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="player_id")
	private Player player;
	public Tournament() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Tournament(int tourid, String map, String modeType, String gameType, int game_id, String gameKey) {
		super();
		this.tourid = tourid;
		this.map = map;
		this.modeType = modeType;
		this.gameType = gameType;
		this.game_id = game_id;
		this.gameKey = gameKey;
	}
	public int getTourid() {
		return tourid;
	}
	public void setTourid(int tourid) {
		this.tourid = tourid;
	}
	public String getMap() {
		return map;
	}
	public void setMap(String map) {
		this.map = map;
	}
	public String getModeType() {
		return modeType;
	}
	public void setModeType(String modeType) {
		this.modeType = modeType;
	}
	public String getGameType() {
		return gameType;
	}
	public void setGameType(String gameType) {
		this.gameType = gameType;
	}
	public int getGame_id() {
		return game_id;
	}
	public void setGame_id(int game_id) {
		this.game_id = game_id;
	}
	public String getGameKey() {
		return gameKey;
	}
	public void setGameKey(String gameKey) {
		this.gameKey = gameKey;
	}
//	public Player getPlayer() {
//		return player;
//	}
//	public void setPlayer(Player player) {
//		this.player = player;
//	}
	@Override
	public String toString() {
		return "Tournament [tourid=" + tourid + ", map=" + map + ", modeType=" + modeType + ", gameType=" + gameType
				+ ", game_id=" + game_id + ", gameKey=" + gameKey + ", player=" + player + "]";
	}
	
	
	
}
