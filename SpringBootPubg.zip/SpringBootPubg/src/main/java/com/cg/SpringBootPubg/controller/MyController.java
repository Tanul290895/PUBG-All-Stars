package com.cg.SpringBootPubg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.cg.SpringBootPubg.dto.Player;
import com.cg.SpringBootPubg.dto.Tournament;
import com.cg.SpringBootPubg.service.PlayerService;

@RestController
@RequestMapping("/player")
public class MyController {
	
	@Autowired
	PlayerService playerservice;
	
	@RequestMapping(value="/add",method= RequestMethod.POST)
public ResponseEntity<Player> addPlayerO(@ModelAttribute("play") Player play) {
		System.out.println(play);
		Player player = playerservice.addPlayer(play);
	
		if(player == null) {
			return new ResponseEntity("Product Not Added",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Player>(player,HttpStatus.OK);
		
	}

	/*@RequestMapping(value="/add",method= RequestMethod.POST)
	public ResponseEntity<Tournament> addTournament(@RequestBody Tournament tour) {
			
			Tournament tournament = playerservice.addtournament(tour);
			if(tournament == null) {
				return new ResponseEntity("Tournament Not Added",HttpStatus.NOT_FOUND);
			}
			
			return new ResponseEntity<Tournament>(tournament,HttpStatus.OK);
			
		}
	@RequestMapping(value="/show",method= RequestMethod.GET)
	public ResponseEntity<List<Tournament>> showAllPlayer(){
		List<Tournament> myList = playerservice.showTournament();
		if(myList.isEmpty()) {
			return new ResponseEntity("No Tournament to show",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Tournament>>(myList,HttpStatus.OK);
		
	}*/
}
