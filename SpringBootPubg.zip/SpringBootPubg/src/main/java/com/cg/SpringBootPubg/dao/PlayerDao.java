package com.cg.SpringBootPubg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.cg.SpringBootPubg.dto.Player;
import com.cg.SpringBootPubg.dto.Tournament;



public interface PlayerDao extends JpaRepository<Player, Integer>{
	
//	public Player findBypid(int pid);

/*	
	public List<Tournament> findByModeType(String modetype);
	public List<Tournament> findByMap(String map);
*/
}
