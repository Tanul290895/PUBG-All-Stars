package com.cg.SpringBootPubg.service;

import java.util.List;

import com.cg.SpringBootPubg.dto.Player;
import com.cg.SpringBootPubg.dto.Tournament;


public interface PlayerService {
	
	public Player addPlayer(Player player) ;
	public List<Tournament> serachByMode(String mode);
	public List<Tournament> searchByMap(String map);
	public List<Tournament> showAll();

}
